package com.jeffyjamzhd.jeffylib.util;

import com.jeffyjamzhd.jeffylib.api.IItemExtendedInteraction;
import net.minecraft.class_1025;
import net.minecraft.class_1026;
import net.minecraft.class_1071;
import net.minecraft.class_416;
import net.minecraft.class_988;
import net.minecraft.src.*;
import org.jetbrains.annotations.ApiStatus;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@ApiStatus.Internal
public class ContainerUtil {
    public static void handleSlotClick(int slotID, int clickType, int action,
                                          class_988 player, CallbackInfoReturnable<class_1071> cir) {
        class_1071 cursorStack = player.field_3999.method_3150();
        if (clickType == 1 && slotID >= 0 && slotID < player.field_3972.method_3250().size()) {
            // Get stack
            class_1026 slotAt = player.field_3972.method_3251(slotID);
            class_1071 stackAt = slotAt.method_3299();

            // Do not run on crafting slot
            if (slotAt instanceof class_1025) {
                return;
            }

            // Do right-click with stack if applicable
            if (stackAt != null && stackAt.method_3421() instanceof IItemExtendedInteraction ext) {
                // Special client stuff
                if (player.field_3248.field_4532) {
                    // Call pre interaction hook, if not in creative inventory
                    if (!(player.field_3972 instanceof class_416)) {
                        ext.beforeExtendedInteraction(stackAt, slotID, action == 1);
                    }
                }

                if (cursorStack != null) {
                    // Check if this interaction can happen
                    if (cursorStack.method_3421() instanceof IItemExtendedInteraction &&
                            !ext.canInteractWithSelf(cursorStack, stackAt)) {
                        return;
                    }

                    // Extended interaction item right-clicked with stack
                    ext.itemRightClickedWithStack(stackAt, cursorStack,
                            player, player.method_5506(), action == 1);
                } else {
                    // Extended interaction item right-clicked
                    ext.itemRightClicked(stackAt, player,
                            player.method_5506(), action == 1);
                }

                cir.setReturnValue(stackAt);
            }

            // Do right-click with cursor stack if applicable
            if (cursorStack != null &&
                    cursorStack.method_3421() instanceof IItemExtendedInteraction ext) {
                // Special client stuff
                if (player.field_3248.field_4532) {
                    // Call pre interaction hook, if not in creative inventory
                    if (!(player.field_3972 instanceof class_416)) {
                        ext.beforeExtendedInteraction(cursorStack, -999, action == 1);
                    }
                }

                // Do not allow nesting
                if (stackAt != null && stackAt.method_3421() instanceof IItemExtendedInteraction &&
                        !ext.canInteractWithSelf(stackAt, cursorStack)) {
                    return;
                }

                // Stack right-clicked with extended interaction item
                class_1071 result;
                if (stackAt != null) {
                    result = ext.itemRightClickedWithStackAsMouseStack(stackAt, cursorStack, player,
                            player.method_5506(), action == 1);
                } else {
                    result = ext.itemRightClickAsMouseStack(cursorStack, player,
                            player.method_5506(), action == 1);
                }
                slotAt.method_3302(result);

                cir.setReturnValue(cursorStack);
            }

            // Update crafting matrix
            player.field_3972.method_3254(slotAt.field_4151);
        }
    }
}
