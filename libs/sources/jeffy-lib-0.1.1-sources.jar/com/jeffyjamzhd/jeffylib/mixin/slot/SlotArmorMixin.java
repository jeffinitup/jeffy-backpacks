package com.jeffyjamzhd.jeffylib.mixin.slot;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1019;
import net.minecraft.class_1028;
import net.minecraft.class_1071;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(class_1019.class)
public class SlotArmorMixin {
    @ModifyReturnValue(method = "isItemValid", at = @At("RETURN"))
    private boolean verifyItemValidity(boolean original,
                                       @Local(ordinal = 0, argsOnly = true) class_1071 stack) {
        if (stack.method_3421() instanceof class_1028 armor) {
            return armor.jl$canBeWorn() && original;
        }
        return original;
    }
}
