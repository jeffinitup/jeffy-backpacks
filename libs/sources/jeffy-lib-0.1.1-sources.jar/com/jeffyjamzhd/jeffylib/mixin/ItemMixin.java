package com.jeffyjamzhd.jeffylib.mixin;

import com.jeffyjamzhd.jeffylib.api.impl.IItem;
import net.minecraft.class_1069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1069.class)
public class ItemMixin implements IItem {
    @Deprecated
    @Override
    public class_1069 jl$setModNamespace(String namespace) {
        return (class_1069) (Object) this;
    }
}
