package com.jeffyjamzhd.jeffylib.mixin.gui;

import com.jeffyjamzhd.jeffylib.api.impl.IGuiScreen;
import com.jeffyjamzhd.jeffylib.api.IItemExtendedInteraction;
import com.llamalad7.mixinextras.sugar.Local;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1025;
import net.minecraft.class_1026;
import net.minecraft.class_1071;
import net.minecraft.class_1600;
import net.minecraft.class_388;
import net.minecraft.class_409;
import net.minecraft.class_988;
import net.minecraft.src.*;
import org.lwjgl.input.Mouse;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_388.class)
@Environment(EnvType.CLIENT)
public abstract class GuiScreenMixin implements IGuiScreen {
    @Shadow public static boolean isShiftKeyDown() {
        return false;
    }
    @Shadow protected class_1600 mc;

    @Unique
    long jl$lastScroll = 0L;
    @Unique
    boolean jl$scrollConsumed = false;

    @Inject(method = "handleMouseInput",
            at = @At(value = "INVOKE", target = "Lorg/lwjgl/input/Mouse;getEventButton()I"), cancellable = true)
    private void mouseScroll(CallbackInfo ci, @Local(ordinal = 0) int x, @Local(ordinal = 1) int y) {
        // Get scroll
        long sysTime = class_1600.method_2912();
        if (sysTime > jl$lastScroll + 25L)
            jl$scrollConsumed = false;
        int dWheel = Mouse.getEventDWheel();

        if (dWheel != 0 && sysTime > jl$lastScroll + 25L) {
            // Handle scroll and consume input
            jl$scrollConsumed = jl$handleMouseScroll(x, y, dWheel);
            jl$lastScroll = sysTime;

            ci.cancel();
        }
    }

    @Unique
    @Override
    public boolean jl$handleMouseScroll(int x, int y, int scroll) {
        if (((class_388) (Object) this) instanceof class_409 container) {
            // Do event handling for slot
            class_1026 slot = container.method_1133(x, y);
            class_988 player = mc.field_3805;

            // Do not process crafting slot
            if (slot instanceof class_1025) {
                return false;
            }

            if (slot != null && slot.method_3301()) {
                // Handle item in slot first
                class_1071 stack = slot.method_3299();
                if (stack.method_3421() instanceof IItemExtendedInteraction ext) {
                    ext.itemScrolled(stack, player, player.method_5506(),
                            scroll > 0 ? 1 : -1, isShiftKeyDown());
                    return true;
                }
            }

            // Check for item in cursor?
            class_1071 stack = mc.field_3805.field_3999.method_3150();
            if (stack != null && stack.method_3421() instanceof IItemExtendedInteraction ext) {
                ext.itemScrolled(stack, player, player.method_5506(),
                        scroll > 0 ? 1 : -1, isShiftKeyDown());
                return true;
            }
        }
        return false;
    }

    @Unique
    @Override
    public boolean jl$isScrollConsumed() {
        return jl$scrollConsumed;
    }
}
