package com.jeffyjamzhd.jeffylib.mixin.gui;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_415;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Environment(EnvType.CLIENT)
@Mixin(value = class_415.class)
public class GuiContainerCreativeMixin {
    @Inject(method = "handleMouseInput", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/src/InventoryEffectRenderer;handleMouseInput()V",
            shift = At.Shift.AFTER), cancellable = true)
    private void cancelScrollInCreative(CallbackInfo ci) {
        if (((class_415) (Object) this).jl$isScrollConsumed()) {
            ci.cancel();
        }
    }

}
