package com.jeffyjamzhd.jeffylib.mixin;

import com.jeffyjamzhd.jeffylib.api.impl.IItemArmor;
import net.minecraft.class_1028;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(class_1028.class)
public class ItemArmorMixin implements IItemArmor {
    @Unique
    public boolean jl$canBeWorn = true;

    @Override
    public boolean jl$canBeWorn() {
        return jl$canBeWorn;
    }

    @Override
    public class_1028 jl$cantBeWorn() {
        this.jl$canBeWorn = false;
        return (class_1028) (Object) this;
    }
}
