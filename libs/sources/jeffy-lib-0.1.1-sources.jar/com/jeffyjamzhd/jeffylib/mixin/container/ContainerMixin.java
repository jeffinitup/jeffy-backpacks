package com.jeffyjamzhd.jeffylib.mixin.container;

import com.jeffyjamzhd.jeffylib.util.ContainerUtil;
import net.minecraft.class_1002;
import net.minecraft.class_1071;
import net.minecraft.class_988;
import net.minecraft.src.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1002.class)
public class ContainerMixin {
    @Inject(method = "slotClick", at = @At("HEAD"), cancellable = true)
    private void slotClick(int slotID, int clickType, int action,
                           class_988 player, CallbackInfoReturnable<class_1071> cir) {
        ContainerUtil.handleSlotClick(slotID, clickType, action, player, cir);
    }
}
