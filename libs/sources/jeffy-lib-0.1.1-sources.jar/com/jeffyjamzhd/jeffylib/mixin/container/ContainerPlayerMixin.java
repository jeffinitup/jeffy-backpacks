package com.jeffyjamzhd.jeffylib.mixin.container;

import btw.inventory.container.PlayerContainer;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1028;
import net.minecraft.class_1069;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(PlayerContainer.class)
public class ContainerPlayerMixin {
    @ModifyExpressionValue(method = "transferStackInSlot", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/src/ItemStack;getItem()Lnet/minecraft/src/Item;",
            ordinal = 0))
    private class_1069 checkArmor(class_1069 original) {
        if (original instanceof class_1028 armor && !armor.jl$canBeWorn()) {
            return null;
        }
        return original;
    }
}
