package com.jeffyjamzhd.jeffylib.api.impl;

import net.minecraft.class_1028;

public interface IItemArmor {
    /**
     * {@code true} if this can be worn as an armor piece
     */
    default boolean jl$canBeWorn() {
        return true;
    }

    /**
     * Sets if this armor piece can be worn.
     */
    default class_1028 jl$cantBeWorn() {
        return null;
    }
}