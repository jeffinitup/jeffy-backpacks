package com.jeffyjamzhd.jeffylib.api.impl;

import net.minecraft.class_1069;
import net.minecraft.class_1071;
import net.minecraft.class_1150;

public interface IItem {
    /**
     * Sets the mod namespace in item
     */
    default class_1069 jl$setModNamespace(String namespace) {
        return null;
    }

    /**
     * Called when this item is destroyed (dropped item entity is destroyed, burned, etc.)
     * @param stack {@link class_1071} that was destroyed
     */
    @SuppressWarnings(value = "unused")
    default void jl$onItemDestroyed(class_1071 stack, class_1150 world, double x, double y, double z) {
    }

    /**
     * Returns item ID to pull icon from for eating particles
     * @param stack {@link class_1071} that is being eaten
     */
    default int jl$getIDForEatingParticle(class_1071 stack) {
        return stack.field_4378;
    }
}
