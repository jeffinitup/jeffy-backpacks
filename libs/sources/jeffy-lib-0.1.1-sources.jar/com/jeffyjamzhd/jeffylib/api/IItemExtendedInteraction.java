package com.jeffyjamzhd.jeffylib.api;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1071;
import net.minecraft.class_1150;
import net.minecraft.class_988;

/**
 * An item that can be interacted by unconventional means,
 * such as right-clicking and scrolling.
 */
public interface IItemExtendedInteraction {
    /**
     * Called before extended interaction hooks on client, usually to
     * send sync/validation packets to server
     */
    @Environment(EnvType.CLIENT)
    void beforeExtendedInteraction(class_1071 item, int slotID, boolean holdingShift);

    /**
     * Determines if any extended item interaction can occur.
     * {@code false} will block the interaction
     */
    boolean canInteractWithSelf(class_1071 cursorStack, class_1071 slotStack);

    /**
     * This item right-clicked.
     * @param holdingShift {@code true} if shift is pressed
     */
    void itemRightClicked(
            class_1071 stack,
            class_988 player,
            class_1150 world,
            boolean holdingShift
    );

    /**
     * This item right-clicked while grabbed by mouse.
     * Assumes there is no stack present at slot.
     * @param holdingShift {@code true} if shift is pressed
     * @return Stack generated from this action (if applicable)
     */
    class_1071 itemRightClickAsMouseStack(
            class_1071 stack,
            class_988 player,
            class_1150 world,
            boolean holdingShift
    );

    /**
     * This item right-clicked with an {@link class_1071} in the cursor slot.
     * @param holdingShift {@code true} if shift is pressed
     */
    void itemRightClickedWithStack(
            class_1071 stack,
            class_1071 cursorStack,
            class_988 player,
            class_1150 world,
            boolean holdingShift
    );

    /**
     * {@link class_1071} right-clicked with this item in the cursor slot.
     * @param holdingShift {@code true} if shift is pressed
     * @return Modified {@code stack}
     */
    class_1071 itemRightClickedWithStackAsMouseStack(
            class_1071 stack,
            class_1071 cursorStack,
            class_988 player,
            class_1150 world,
            boolean holdingShift
    );

    /**
     * {@link class_1071} hovered over is being scrolled
     *
     * @param direction    Scroll direction
     * @param holdingShift {@code true} if shift is pressed
     */
    void itemScrolled(
            class_1071 item,
            class_988 player,
            class_1150 world,
            int direction,
            boolean holdingShift
    );
}
